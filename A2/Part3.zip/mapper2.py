#!/usr/bin/env python 

import sys
import os 

for line in sys.stdin:
    word1, word2, filename, bigram_count = line.strip().split('\t')
    print('%s\t%s\t%s\t%s' % (word1, word2, filename, bigram_count))
