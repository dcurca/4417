#!/usr/bin/env python

from operator import itemgetter
import sys

for line in sys.stdin:
    word1, word2, filename, bigram_count = line.strip().split('\t')

    if int(bigram_count) == 1:
        print('((%s, %s)%s, %s)' % (word1, word2, filename, bigram_count))
