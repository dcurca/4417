#!/usr/bin/env python

from operator import itemgetter
import sys

current_word1 = None
current_word2 = None
current_count = 0 
current_docID = None
word1 = None
word2 = None

for line in sys.stdin:
    word1, word2, fileName, count = line.strip().split('\t')

    try: 
        count = int(count)
    except ValueError:
        continue

    if current_word1 == word1 and current_word2 == word2 and current_docID == fileName:
        current_count += count
    else: 
        if current_word1 and current_docID:
            print('%s\t%s\t%s\t%s' % (current_word1, current_word2, current_docID, current_count))
        current_count = count
        current_word1 = word1
        current_word2 = word2
        current_docID = fileName

if current_word1 == word1 and current_word2 == word2 and current_docID == fileName:
    print('%s\t%s\t%s\t%s' % (current_word1, current_word2, current_docID, current_count))


