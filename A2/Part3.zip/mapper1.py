#!/usr/bin/env python

import sys
import re
import os

for line in sys.stdin:
    words = line.strip().split()
    fileName = os.environ["map_input_file"]
    for i in range(len(words)-1):
        print('%s\t%s\t%s\t%s' % (words[i], words[i+1], fileName, 1))
