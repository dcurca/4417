#!/usr/bin/env python

import sys 
import os
import math

tf = 0 
idf = 0 
tfIDF = 0

for line in sys.stdin:
    word, filename, count, doc_count, word_count, occurrence = line.strip().split('\t')
    tf = float(count)
    idf = math.log10(int(doc_count)/float(occurrence))
    tfIDF = (tf/float(word_count))*idf
    print ("((%s,%s),(%s, %s, %s))" % (filename, word, tf, idf, tfIDF))
