import sys 
import os

for line in sys.stdin:
    word, filename, count, doc_count, word_count = line.strip().split('\t') 
    print ('%s\t%s\t%s\t%s\t%s\t%s' % (word, filename, count, doc_count, word_count, 1))
