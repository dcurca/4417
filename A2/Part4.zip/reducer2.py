import sys 

current_word = None
current_count = None
word_list = []

for line in sys.stdin:
    word, filename, termcount, doc_count, word_count, count = line.strip().split('\t')
    current_wordl = ("%s\t%s\t%s\t%s\t%s" % (word, filename, termcount, doc_count, word_count))
    if word == None:
        current_word = word
        current_count = eval(count)
        word_list.append(current_wordl)
    elif current_word == word:
        current_count += eval(count)
        word_list.append(current_wordl)
    else: 
        for i in word_list:
            print ("%s\t%d" % (i, current_count))
        current_word = word
        current_count = eval(count)
        word_list = [current_wordl]

for i in word_list:
    print ("%s\t%d" % (i, current_count))
