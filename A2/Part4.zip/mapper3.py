#!/usr/bin/env python

import sys 
import os

for line in sys.stdin:
    word, filename, count, doc_count, word_count, occurrence = line.strip().split('\t')
    print("%s\t%s\t%s\t%s\t%s\t%s" % (word, filename, count, doc_count, word_count, occurrence))
