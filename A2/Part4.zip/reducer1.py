#!usr/bin/env python

import sys

current_wordfile = None
current_count = None
doc_count = 0
word_count = 0

for line in sys.stdin:
    word, filename, count, doc_count, word_count = line.strip().split('\t')
    current_word = ('%s' % (word))
    wordfile = ('%s\t%s' % (word, filename)) 

    if current_wordfile == None:
        current_wordfile = wordfile
        current_word = word
        current_count = eval(count)
    elif current_wordfile == wordfile:
        current_count += eval(count)
    else:
        print ("%s\t%s\t%s\t%s" % (current_wordfile, current_count, doc_count, word_count))
        current_wordfile = wordfile
        current_word = word
        current_count = eval(count)

print ("%s\t%s\t%s\t%s" % (current_wordfile, current_count, doc_count, word_count))
