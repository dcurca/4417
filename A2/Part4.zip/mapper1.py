#!/usr/bin/env python

import sys 
import os
import glob

path = '/home/dcurca/inputDirectory/Documents'

file_list = list()
directory_name = glob.glob(path+"/*")
doc_count = 0
word_count = 0

for file in directory_name:
    doc_count += 1 
    file_list.append(file)

fp = list()
for file in file_list:
    filename = os.path.basename(file)
    fp = open(file).readlines()
    for n,line in enumerate(fp):
        fp[n] = line.rstrip() 
        line = ' '.join(fp)
    line = line.split() 
    word_count = len(line)
    for word in line: 
        print("%s\t%s\t%s\t%s\t%s" % (word, filename, 1, doc_count, word_count))
