#!/usr/bin/python

from operator import itemgetter
import sys

current_word = None
current_docID = None
current_count = 0
word = None

for line in sys.stdin:
    line = line.strip()
    word, document_id, count = line.split('\t', 2)

    try:
        count = int(count)
    except ValueError:
        continue

    if current_word == word and current_docID == document_id:
        current_count += count
    else:
        if current_word and current_docID:
            print('((%s,%s),%s)' % (current_word, current_docID, current_count))
        current_count = count
        current_word = word
        current_docID = document_id
