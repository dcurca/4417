 #!/usr/bin/python
import sys
import os
import glob

path = '/home/dcurca/inputDirectory'

file_list = list()
directory_name = glob.glob(path+'/*')
doc_identifier = ""
for file in directory_name:
    if not file.endswith('py'):
        file_list.append(file) 

for file in file_list:
    doc_identifier = os.path.basename(file)
    fp = open(file)
    for line in fp.readlines():
        line  = line.strip()
        words = line.split()
        for word in words:
            print('%s\t%s\t%s' % (word, doc_identifier, 1))
 
